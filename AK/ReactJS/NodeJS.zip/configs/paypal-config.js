module.exports = {
  'mode': 'sandbox', //sandbox or live
  'client_id': 'AWijdE5xWwu7gyt-rkEjgvucwKrC3vTFhwY4L-FMXZAQSKJzQdJY-d0I51JJZxwFag6mCcDhTVEX-WYk',
  'client_secret': 'EAWr7rG9XVeyK2RLLvg1tdrOzqQj1RaEVI6jIWNkrDpTTUKXfOUBtZFSDNJ-DZ_uOCQts_Kt_GqO8Xn9'
} 
