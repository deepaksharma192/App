//replace <username> and <password> with your mongoDB atlas accounts info
//module.exports = "mongodb://heroku_8bd94qrf:irstf0rv1ds970eebtislm0apf@ds029638.mlab.com:29638/heroku_8bd94qrf"

module.exports = "mongodb+srv://test123:Deepak@123@cluster0-qxpku.mongodb.net/LMSDB?retryWrites=true&w=majority"

//test123 Deepak@123  182.74.87.18


