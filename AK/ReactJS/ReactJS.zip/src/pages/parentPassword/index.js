import React, {Component} from 'react';
import Headers from '../../HOC/Headers';

class Parentpassword extends Component{

    render(){

        return(
            <div>
                Parentpassword
            </div>
        )
    }
}

export default Headers(Parentpassword)