import React, {Component} from 'react';
import Headers from '../../HOC/Headers';

class Practicequiz extends Component{

    render(){

        return(
            <div>
                Practice Quiz
            </div>
        )
    }
}

export default Headers(Practicequiz)