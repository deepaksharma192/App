import React, {Component} from 'react';
import Headers from '../../HOC/Headers';

class Customersupport extends Component{

    render(){

        return(
            <div>
                Customersupport
            </div>
        )
    }
}

export default Headers(Customersupport)