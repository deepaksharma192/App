const CON = {
    siteName:"",
    restrictedUrl:["/dashboard","/profile"]
    
}
export default CON;